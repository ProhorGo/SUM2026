/* FILE NAME: units.h
 * PROGRAMMER: PG3
 */

#include "anim\anim.h"

// struct pg3ANIM;   // new

pg3UNIT * PG3_UnitCreateBall( VEC Pos );
/* VOID PG3_KeyboardInit( VOID );
VOID PG3_MouseInit( VOID );
VOID PG3_KeyboardResponse( pg3UNIT_CONTROL *Uni, pg3ANIM *Ani );
VOID PG3_MouseResponse( pg3UNIT_CONTROL *Uni, pg3ANIM *Ani );   */

//  extern pg3UNIT_CONTROL PG3_Move;
extern INT PG3_MouseWheel;

struct pg3UNIT_CONTROL;


/* END of 'units.h' FILE */
