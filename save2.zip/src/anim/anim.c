/* FILE NAME: anim.c
 * PROGRAMMER: PG3
 */

#include "anim.h"
#include <stdio.h>

pg3ANIM PG3_Anim;
//INT PG3_MouseWheel;

VOID PG3_AnimInit( HWND hWnd )
{
  PG3_Anim.hWnd = hWnd;
  PG3_RndInit(hWnd);

  PG3_TimerInit();
  PG3_AnimInputInit();
}

VOID PG3_AnimClose( VOID )
{
  INT i;

  for (i = 0; i < PG3_Anim.NumOfUnits; i++)
  {
    PG3_Anim.Units[i]->Close(PG3_Anim.Units[i], &PG3_Anim);
    free(PG3_Anim.Units[i]);
  }
  PG3_Anim.NumOfUnits = 0;
  PG3_RndClose();
}

VOID PG3_AnimResize( INT W, INT H )
{
  PG3_RndResize(W, H);
}

VOID PG3_AnimCopyFrame( VOID )
{
  PG3_RndCopyFrame();
}

VOID PG3_AnimRender( VOID )
{
  INT i;
  /* char head[100];  */

  PG3_TimerResponse();
  PG3_AnimInputResponse();

  for (i = 0; i < PG3_Anim.NumOfUnits; i++)
    PG3_Anim.Units[i]->Response(PG3_Anim.Units[i], &PG3_Anim);

  PG3_RndStart();
  for (i = 0; i < PG3_Anim.NumOfUnits; i++)
    PG3_Anim.Units[i]->Render(PG3_Anim.Units[i], &PG3_Anim);
  PG3_RndEnd();
}

VOID PG3_AnimUnitAdd( pg3UNIT *Uni )
{
  if (PG3_Anim.NumOfUnits < PG3_MAX_UNITS)
    PG3_Anim.Units[PG3_Anim.NumOfUnits++] = Uni, Uni->Init(Uni, &PG3_Anim);
}

/* END of 'anim.c' FILE */
