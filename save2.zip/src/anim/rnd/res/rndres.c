/* FILE NAME: rndres.c
 * PROGRAMMER: PG3
 */

#include "rndres.h"

VOID PG3_RndResInit( VOID )
{
  PG3_RndShdInit();
  PG3_RndMtlInit();
  PG3_RndTexInit();
}

VOID PG3_RndResClose( VOID )
{
  PG3_RndTexClose();
  PG3_RndMtlClose();
  PG3_RndShdClose();
}

/* END of 'rndres.c' FILE */