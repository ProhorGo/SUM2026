/* FILE NAME: rndres.c
 * PROGRAMMER: PG3
 */

#include "anim/rnd/rnd.h"


PG3_RndTexInit()
{
}

PG3_RndTexClose()
{
}