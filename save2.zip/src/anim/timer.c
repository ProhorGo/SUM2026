/* FILE NAME: timer.c
 * PROGRAMMER: PG3
 */

#include "anim.h"
#include <time.h>

static UINT64
    StartTime = 0,    /* Start program time */
    OldTime = 0,      /* Previous frame time */
    OldTimeFPS = 0,   /* Old time FPS measurement */
    PauseTime = 0,    /* Time during pause period */
    TimePerSec = 0,   /* Timer resolution */
    FrameCount = 0; 

VOID PG3_TimerInit( VOID )
{
  StartTime = OldTime = OldTimeFPS = clock();
  PauseTime = 0;
  FrameCount = 0;
  PG3_Anim.IsPause = FALSE;
  PG3_Anim.Time = PG3_Anim.DeltaTime = 0;
  PG3_Anim.FPS = 30;
}
 
VOID PG3_TimerResponse( VOID )
{
  LONG t = clock();
 
  if (!PG3_Anim.IsPause)
  {             
    PG3_Anim.Time = (DBL)(t - PauseTime - StartTime) / CLOCKS_PER_SEC;
    PG3_Anim.DeltaTime = (DBL)(t - OldTime) / CLOCKS_PER_SEC;
  }
  else
  {
    PG3_Anim.DeltaTime = 0;
    PauseTime += t - OldTime;
  }
 
  FrameCount++;
  if (t - OldTimeFPS > CLOCKS_PER_SEC)
  {
    PG3_Anim.FPS = FrameCount / ((DBL)(t - OldTimeFPS) / CLOCKS_PER_SEC);
    OldTimeFPS = t;
    FrameCount = 0;
  }
  OldTime = t;
}
    
/* END of 'timer.c' FILE */