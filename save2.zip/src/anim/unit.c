/* FILE NAME: units.c
 * PROGRAMMER: PG3
 */

#include "anim.h"

/* Unit initialization function.
 * ARGUMENTS:
 *   - self-pointer to unit object:
 *       pg3UNIT *Uni;
 *   - animation context:
 *       pg3ANIM *Ani;
 * RETURNS: None.
 */
static VOID PG3_UnitInit( pg3UNIT *Uni, pg3ANIM *Ani )
{
} /* End of 'PG3_UnitInit' function */

/* Unit deinitialization function.
 * ARGUMENTS:
 *   - self-pointer to unit object:
 *       pg3UNIT *Uni;
 *   - animation context:
 *       pg3ANIM *Ani;
 * RETURNS: None.
 */
static VOID PG3_UnitClose( pg3UNIT *Uni, pg3ANIM *Ani )
{
} /* End of 'PG3_UnitClose' function */

/* Unit inter frame events handle function.
 * ARGUMENTS:
 *   - self-pointer to unit object:
 *       pg3UNIT *Uni;
 *   - animation context:
 *       pg3ANIM *Ani;
 * RETURNS: None.
 */
static VOID PG3_UnitResponse( pg3UNIT *Uni, pg3ANIM *Ani )
{
} /* End of 'PG3_UnitResponse' function */

/* Unit render function.
 * ARGUMENTS:
 *   - self-pointer to unit object:
 *       pg3UNIT *Uni;
 *   - animation context:
 *       pg3ANIM *Ani;
 * RETURNS: None.
 */
static VOID PG3_UnitRender( pg3UNIT *Uni, pg3ANIM *Ani )
{
} /* End of 'PG3_UnitRender' function */
 
/* Unit creation function.
 * ARGUMENTS:
 *   - unit structure size in bytes:
 *       INT Size;
 * RETURNS:
 *   (pg3UNIT *) pointer to created unit.
 */
pg3UNIT * PG3_AnimUnitCreate( INT Size )
{
  pg3UNIT *Uni;

  /* Memory allocation */
  if (Size < sizeof(pg3UNIT) || (Uni = malloc(Size)) == NULL)
    return NULL;
  memset(Uni, 0, Size);

  /* Setup unit methods */
  Uni->Init = PG3_UnitInit;
  Uni->Close = PG3_UnitClose;
  Uni->Response = PG3_UnitResponse;
  Uni->Render = PG3_UnitRender;
 
  return Uni;
} /* End of 'PG3_AnimUnitCreate' function */

/* END of 'unit.c' FILE */
