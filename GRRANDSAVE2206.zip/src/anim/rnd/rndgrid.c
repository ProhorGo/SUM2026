/* FILE NAME: rndgrid.c
 * PROGRAMMER: PG3
 */

#include "rnd.h"

BOOL PG3_RndGridCreate( pg3GRID *G, INT W, INT H )
{
  memset(G, 0, sizeof(pg3GRID));
  G->W = W;
  G->H = H;
  if ((G->V = malloc(sizeof(pg3VERTEX) * W * H)) == NULL)
    return FALSE;
  memset(G->V, 0, sizeof(pg3VERTEX) * W * H);
  return TRUE;
}

VOID PG3_RndGridFree( pg3GRID *G )
{
  free(G->V);
  memset(G, 0, sizeof(pg3GRID));
}

VOID PG3_RndPrimFromGrid( pg3PRIM *Pr, pg3GRID *G )
{
  INT k, i, j, num_of_indices;
  INT *Ind;

  memset(Pr, 0, sizeof(pg3PRIM));
  num_of_indices = (G->W * 2 + 1 ) * (G->H - 1) - 1;

  if ((Ind = malloc(sizeof(INT) * num_of_indices)) == NULL)
    return;

  for (k = 0, i = 0; i < G -> H - 1; i++)
  {
    for (j = 0; j < G->W; j++)
    {
      Ind[k++] = (i + 1) * G->W + j; 
	  Ind[k++] = i * G->W + j;
    }
    if (i != G->H - 2)
      Ind[k++] = -1;
  }
  PG3_RndPrimCreate(Pr, PG3_RND_PRIM_TRISTRIP, G->V, G->W * G->H, Ind, num_of_indices);
  free(Ind);
}

VOID PG3_RndGridAutoNormals( pg3GRID *G )
{
  INT i, j;
	
  for (i = 0; i < G->W * G->H; i++)
    G->V[i].N = VecSet(0, 0, 0);

  for ( i = 0; i < G->H - 1 ;i++) 
    for ( j = 0; j < G->W - 1 ;j++)
    {
      pg3VERTEX
        *P00 = G->V + i * G->W + j,
        *P01 = G->V + i * G->W + j + 1 ,
        *P10 = G->V + (i + 1) * G->W + j,
		*P11 = G->V + (i + 1) * G->W + j + 1;
      VEC N;
      N = VecNormalize (VecCrossVec (VecSubVec (P00->P, P10->P),
                                     VecSubVec (P11->P, P10->P)));
      P00->N = VecAddVec (P00->N, N);
      P10->N = VecAddVec (P10->N, N);
      P11->N = VecAddVec (P11->N, N);

      N = VecNormalize (VecCrossVec (VecSubVec (P11->P, P01->P), 
                                     VecSubVec (P00->P, P01->P)));
      P00->N = VecAddVec (P00->N, N);
      P01->N = VecAddVec (P01->N, N);
      P11->N = VecAddVec (P11->N, N);
    }

    for (i = 0; i < G->W * G->H; i++)
      G->V[i].N = VecNormalize(G->V[i].N);
}

BOOL PG3_RndGridCreateSphere( pg3GRID *G, FLT R, INT W, INT H )
{
  INT i, j, k;
  DBL theta, phi;

  if (!PG3_RndGridCreate(G, W, H))
    return FALSE;

  /* Fill vertex array */    
  for (k = 0, i = 0, theta = 0; i < H; i++, theta += PI / (H - 1))
    for (j = 0, phi = 0; j < W; j++, phi += 2 * PI / (W - 1))
    {
      G->V[k].N = VecSet(sin(theta) * sin(phi),
                      cos(theta),
                      sin(theta) * cos(phi));
      G->V[k].C = Vec4Set(1, 1, 1, 1);
      G->V[k++].P = VecSet(R * sin(theta) * sin(phi),
                           R * cos(theta),
                           R * sin(theta) * cos(phi));
    }
  return TRUE;
}

/* END of 'rnddata.c' FILE */