/* FILE NAME: u_ctrl.c
 * PROGRAMMER: PG3
 */

#include "units.h"
#include <stdio.h>
#include <math.h>
#include <time.h>
 
typedef struct tagpg3UNIT_CONTROL
{
  PG3_UNIT_BASE_FIELDS;
  VEC CamLoc, CamAt;
  DBL Speed;
  DBL Dist, Azimuth, Elevator;
} pg3UNIT_CONTROL;

static pg3UNIT_CONTROL PG3_Move;  

static VOID PG3_UnitInit( pg3UNIT_CONTROL *Uni, pg3ANIM *Ani )
{
  Uni->CamAt = VecSet(0, 0, 0);
  Uni->Speed = 5;
  Uni->Dist = 10;
  Uni->Azimuth = 180;
  Uni->Elevator = 30;
  Uni->CamLoc = VecSet(Uni->CamAt.X + Uni->Dist * cos(D2R(Uni->Elevator)) * sin(D2R(Uni->Azimuth)),
                       Uni->CamAt.Y + Uni->Dist * sin(D2R(Uni->Elevator)),
                       Uni->CamAt.Z + Uni->Dist * cos(D2R(Uni->Elevator)) * cos(D2R(Uni->Azimuth)));

  PG3_RndCamSet(Uni->CamLoc, Uni->CamAt, VecSet(0, 1, 0));
  ShowCursor(FALSE);
} 

static VOID PG3_UnitClose( pg3UNIT_CONTROL *Uni, pg3ANIM *Ani )
{
}

static VOID PG3_UnitRender( pg3UNIT_CONTROL *Uni, pg3ANIM *Ani )
{
  char head[102];

  if (Ani->IsPause)
    sprintf(head, "PAUSE");
  else          
    sprintf(head, "FPS: %.3f", Ani->FPS);
  SetWindowText(Ani->hWnd, head);
}

static VOID PG3_UnitResponse( pg3UNIT_CONTROL *Uni, pg3ANIM *Ani )
{
  VEC d, e, h;
  DBL FullSpeed = Uni->Speed * Ani->DeltaTime * 3;
  static VEC angle = {0, 0, 0};
  POINT pt;
  RECT rc, rc1;
  INT k = 20, j = 1000;
  static BOOL IsMouse = FALSE;

  if (Ani->KeysClick['P'])
    Ani->IsPause = !Ani->IsPause;
  if (Ani->KeysClick[VK_ESCAPE])
    SendMessage(Ani->hWnd, WM_CLOSE, 0, 0);
  if (Ani->KeysClick[VK_F11])
    Uni->CamAt = VecSet(0, 0, 0);
  if (Ani->KeysClick[VK_F8])
  {
    HANDLE hCon = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_SCREEN_BUFFER_INFO info;
    DWORD NumCharsWritten;
    COORD Pos = {0};
 
    GetConsoleScreenBufferInfo(hCon, &info);
    FillConsoleOutputCharacter(hCon, ' ',
      (UINT)(info.dwSize.X * info.dwSize.Y), Pos, &NumCharsWritten);  
    FillConsoleOutputAttribute(hCon, 0x0F,
      (UINT)(info.dwSize.X * info.dwSize.Y), Pos, &NumCharsWritten);  
    SetConsoleCursorPosition(hCon, info.dwCursorPosition);
    SetConsoleCursorPosition(hCon, Pos);
  }

  if (!Ani->IsPause)
  { 
    POINT curMouse;
    GetClientRect(Ani->hWnd, &rc);
    pt.x = rc.right / 2;
    pt.y = rc.bottom / 2;
    ClientToScreen(Ani->hWnd, &pt);

    GetCursorPos(&curMouse);

    Ani->Mdx = curMouse.x - pt.x;
    Ani->Mdy = curMouse.y - pt.y;
    IsMouse = FALSE;

    /* ��� */ 
   
    Uni->Azimuth -= Ani->Mdx * 0.1;
    Uni->Elevator += Ani->Mdy * 0.1;

    if (Uni->Elevator > 80)
      Uni->Elevator = 80;
    if (Uni->Elevator < -80)
      Uni->Elevator = -80;

    /* �������� */    
    if (Ani->Mdz != 0)
    {
      Uni->Dist -= Ani->Mdz * 0.5;
      if (Uni->Dist < 00.2)
        Uni->Dist = 0.02;
      if (Uni->Dist > 50)
        Uni->Dist = 50;
    }
    /* �������� */  
    if (Ani->Keys[VK_LCONTROL])
      k *= 2;
                      
    d = VecSet(sin(D2R(Uni->Azimuth)), 0, cos(D2R(Uni->Azimuth)));
    e = VecSet(cos(D2R(Uni->Azimuth)), 0, -sin(D2R(Uni->Azimuth)));

    h = VecSet(0, sin(D2R(Uni->Azimuth)), 0);

    if (Ani->Keys['W'])
      Uni->CamAt = VecSubVec(Uni->CamAt, VecMulNum(d, FullSpeed * k));
    if (Ani->Keys['A'])
      Uni->CamAt = VecSubVec(Uni->CamAt, VecMulNum(e, FullSpeed * k));
    if (Ani->Keys['S'])
      Uni->CamAt = VecAddVec(Uni->CamAt, VecMulNum(d, FullSpeed * k));
    if (Ani->Keys['D'])
      Uni->CamAt = VecAddVec(Uni->CamAt, VecMulNum(e, FullSpeed * k));
    if (Ani->Keys[VK_SPACE])
      Uni->CamAt = VecAddVec(Uni->CamAt, VecSet(0, FullSpeed * k, 0));
    if (Ani->Keys[VK_LSHIFT])
      Uni->CamAt = VecSubVec(Uni->CamAt, VecSet(0, FullSpeed * k, 0));
                    
    Uni->CamLoc = VecSet(Uni->CamAt.X + Uni->Dist * cos(D2R(Uni->Elevator)) * sin(D2R(Uni->Azimuth)),
                         Uni->CamAt.Y + Uni->Dist * sin(D2R(Uni->Elevator)),
                         Uni->CamAt.Z + Uni->Dist * cos(D2R(Uni->Elevator)) * cos(D2R(Uni->Azimuth)));
    Pos = Uni->CamLoc;  
                  
    PG3_RndCamSet(Uni->CamLoc, Uni->CamAt, VecSet(0, 1, 0)); 
   
    rc1 = rc;
    ClientToScreen(Ani->hWnd, (POINT *)&rc1.left);
    ClientToScreen(Ani->hWnd, (POINT *)&rc1.right);
    ClipCursor(&rc1);

    IsMouse = TRUE;
    SetCursorPos(pt.x, pt.y);
  }
} 

/*
static VOID PG3_UnitResponse( pg3UNIT_CONTROL *Uni, pg3ANIM *Ani )
{
  VEC d, e;
  DBL FullSpeed = Uni->Speed * Ani->DeltaTime * 3;
  RECT rc;
  POINT pt;
  static VEC angle = {0, 0, 0};
  INT k = 20, j = 75;

  if (Ani->KeysClick['P'])
    Ani->IsPause = !Ani->IsPause;
  if (Ani->KeysClick[VK_ESCAPE])
    SendMessage(Ani->hWnd, WM_CLOSE, 0, 0);
  if (Ani->KeysClick[VK_F11])
    Uni->CamAt = VecSet(0, 0, 0);
  if (Ani->KeysClick[VK_F8])
  {
    HANDLE hCon = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_SCREEN_BUFFER_INFO info;
    DWORD NumCharsWritten;
    COORD Pos = {0};
 
    GetConsoleScreenBufferInfo(hCon, &info);
    FillConsoleOutputCharacter(hCon, ' ',
      (UINT)(info.dwSize.X * info.dwSize.Y), Pos, &NumCharsWritten);  
    FillConsoleOutputAttribute(hCon, 0x0F,
      (UINT)(info.dwSize.X * info.dwSize.Y), Pos, &NumCharsWritten);  
    SetConsoleCursorPosition(hCon, info.dwCursorPosition);
    SetConsoleCursorPosition(hCon, Pos);
  }

  if (!Ani->IsPause)
  {
    angle.Y -= Ani->Mdx * 0.003;
    angle.X -= Ani->Mdy * 0.003;

    GetClientRect(Ani->hWnd, &rc);
    pt.x = rc.right / 2;
    pt.y = rc.bottom / 2;
    ClientToScreen(Ani->hWnd, &pt);
    // SetCursorPos(pt.x, pt.y);

    d = VecNormalize(VecSet(sin(angle.Y) * cos(angle.X), sin(angle.X), cos(angle.Y) * cos(angle.X)));
    e = VecNormalize(VecCrossVec(d, VecSet(0, 1, 0)));

    Uni->CamLoc =
	  PointTransform(Uni->CamLoc,
	    MatrRotateY(Ani->Keys[VK_LBUTTON] * -0.5 * Ani->Mdx));     

    if (Ani->Keys['W'])
	  Uni->CamLoc = VecAddVec(Uni->CamLoc, VecMulNum(d, FullSpeed * k));
    if (Ani->Keys['S'])
	  Uni->CamLoc = VecSubVec(Uni->CamLoc, VecMulNum(d, FullSpeed * k));
    if (Ani->Keys['D'])
	  Uni->CamLoc = VecAddVec(Uni->CamLoc, VecMulNum(e, FullSpeed * k));
    if (Ani->Keys['A'])
	  Uni->CamLoc = VecSubVec(Uni->CamLoc, VecMulNum(e, FullSpeed * k));
    if (Ani->Keys[VK_SPACE])
	  Uni->CamLoc = VecAddVec(Uni->CamLoc, VecSet(0, FullSpeed, 0));
    if (Ani->Keys[VK_LSHIFT])
	  Uni->CamLoc = VecSubVec(Uni->CamLoc, VecSet(0, FullSpeed, 0));

	if (Ani->Keys['W'] && Ani->Keys[VK_LCONTROL])
	  Uni->CamLoc = VecAddVec(Uni->CamLoc, VecMulNum(d, FullSpeed * j));
	if (Ani->Keys['S'] && Ani->Keys[VK_LCONTROL])
	  Uni->CamLoc = VecSubVec(Uni->CamLoc, VecMulNum(d, FullSpeed * j));
    if (Ani->Keys['D'] && Ani->Keys[VK_LCONTROL])
	  Uni->CamLoc = VecAddVec(Uni->CamLoc, VecMulNum(e, FullSpeed * j));
    if (Ani->Keys['A'] && Ani->Keys[VK_LCONTROL])
	  Uni->CamLoc = VecSubVec(Uni->CamLoc, VecMulNum(e, FullSpeed * j));

    Uni->CamAt = VecAddVec(Uni->CamLoc, d);
    PG3_RndCamSet(Uni->CamLoc, Uni->CamAt, VecSet(0, 1, 0));
  }
}*/

pg3UNIT * PG3_UnitCreateControl( VOID )
{
  pg3UNIT *Uni;

  if ((Uni = PG3_AnimUnitCreate(sizeof(pg3UNIT_CONTROL))) == NULL)
    return NULL;
  Uni->Init = (VOID *)PG3_UnitInit;
  Uni->Close = (VOID *)PG3_UnitClose;
  Uni->Response = (VOID *)PG3_UnitResponse;
  Uni->Render = (VOID *)PG3_UnitRender;
  return Uni;
}  
