/* FILE NAME: units.h
 * PROGRAMMER: PG3
 */

#include "anim\anim.h"

pg3UNIT * PG3_UnitCreateBall( VEC Pos );

extern INT PG3_MouseWheel;

struct pg3UNIT_CONTROL;

VEC Pos;

pg3UNIT * PG3_UnitCreateTexture( VOID );

pg3UNIT * PG3_UnitCreateLandscape( VOID );

pg3UNIT * PG3_UnitCreateG3DM( VOID );

pg3UNIT * PG3_UnitCreateMumi( VOID );

pg3UNIT * PG3_UnitCreateTREE1( VOID );

pg3UNIT * PG3_UnitCreateTREE2( VOID );
/* END of 'units.h' FILE */
