/* FILE NAME: u_g3dm.c
 * PROGRAMMER: PG3
 */

#include "units.h"

typedef struct tagpg3UNIT_G3DM
{
  PG3_UNIT_BASE_FIELDS;
  pg3PRIMS Model;
  VEC Pos;
} pg3UNIT_G3DM;

/* Unit initialization function.
 * ARGUMENTS:
 *   - self-pointer to unit object:
 *       pg3UNIT_G3DM *Uni;
 *   - animation context:
 *       pg3ANIM *Ani;
 * RETURNS: None.
 */
static VOID PG3_UnitInit( pg3UNIT_G3DM *Uni, pg3ANIM *Ani )
{
  // //Uni->Pos = VecSet(0, 1, 0);
  PG3_RndPrimsLoad(&Uni->Model, "bin/models/Giraf.g3dm");
} /* End of 'PG3_UnitInit' function */

/* Unit deinitialization function.
 * ARGUMENTS:
 *   - self-pointer to unit object:
 *       pg3UNIT_G3DM *Uni;
 *   - animation context:
 *       pg3ANIM *Ani;
 * RETURNS: None.
 */
static VOID PG3_UnitClose( pg3UNIT_G3DM *Uni, pg3ANIM *Ani )
{
  PG3_RndPrimsFree(&Uni->Model);
} /* End of 'PG3_UnitClose' function */

/* Unit inter frame events handle function.
 * ARGUMENTS:
 *   - self-pointer to unit object:
 *       pg3UNIT_G3DM *Uni;
 *   - animation context:
 *       pg3ANIM *Ani;
 * RETURNS: None.
 */
static VOID PG3_UnitResponse( pg3UNIT_G3DM *Uni, pg3ANIM *Ani )
{
  if (!Ani->IsPause)
    ;
  //Uni->Pos.Y = fabs(10 * sin(Ani->DeltaTime * 2.4));
} /* End of 'PG3_UnitResponse' function */

/* Unit render function.
 * ARGUMENTS:
 *   - self-pointer to unit object:
 *       pg3UNIT_G3DM *Uni;
 *   - animation context:
 *       pg3ANIM *Ani;
 * RETURNS: None.
 */
static VOID PG3_UnitRender( pg3UNIT_G3DM *Uni, pg3ANIM *Ani )
{
  PG3_RndPrimsDraw(&Uni->Model, MatrIdentity());
} /* End of 'PG3_UnitRender' function */

pg3UNIT * PG3_UnitCreateTREE1( VOID )
{
  pg3UNIT_G3DM *Uni;

  if ((Uni = (pg3UNIT_G3DM *)PG3_AnimUnitCreate(sizeof(pg3UNIT_G3DM))) == NULL)
    return NULL;
  Uni->Init = (VOID *)PG3_UnitInit;
  Uni->Close = (VOID *)PG3_UnitClose;
  Uni->Response = (VOID *)PG3_UnitResponse;
  Uni->Render = (VOID *)PG3_UnitRender;
  return (pg3UNIT *)Uni;
}

/* END of 'u_Model.c' FILE */

