/* FILE NAME: u_ball.h
 * PROGRAMMER: PG3
 */

#include "units.h"
#include <stdio.h>

typedef struct tagpg3UNIT_TEXTURE
{
  PG3_UNIT_BASE_FIELDS;
  pg3PRIM Pr;
  UINT MtlNo, TexId;
} pg3UNIT_TEXTURE;

/* Unit initialization function.
 * ARGUMENTS:
 *   - self-pointer to unit object:
 *       pg3UNIT_BALL *Uni;
 *   - animation context:
 *       pg3ANIM *Ani;
 * RETURNS: None.
 */
static VOID PG3_UnitInit( pg3UNIT_TEXTURE *Uni, pg3ANIM *Ani )
{
  pg3VERTEX V[] =
  {
    {{0, 0, 0}, {0, 0}, {0, 0, 1}, {1, 1, 1, 1}},
    {{1, 0, 0}, {1, 0}, {0, 0, 1}, {1, 1, 1, 1}},
    {{0, 1, 0}, {0, 1}, {0, 0, 1}, {1, 1, 1, 1}},
    {{1, 1, 0}, {1, 1}, {0, 0, 1}, {1, 1, 1, 1}},
  };
 
  FLT t[2][2] =
  {
    {0.8, 1},
    {1, 0.3}
  };
  pg3MATERIAL mtl = PG3_RndMtlGetDef();

  strncpy(mtl.Name, "Texture sample", PG3_STR_MAX - 1);
  mtl.ShdNo = PG3_RndShdAdd("default");
  Uni->MtlNo = PG3_RndMtlAdd(&mtl);

  glGenTextures(1, &Uni->TexId);
  glBindTexture(GL_TEXTURE_2D, Uni->TexId);
  glTexImage2D(GL_TEXTURE_2D, 0, 1, 2, 2, 0, GL_LUMINANCE, GL_FLOAT, t);

 /* glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
   */
  PG3_RndPrimCreate(&Uni->Pr, PG3_RND_PRIM_TRISTRIP, V, 4, NULL, 0);
  Uni->Pr.MtlNo = Uni->MtlNo;
  /*
  if ((F = fopen("", "rb")) != NULL)
  {
    INT w = 0, h = 0;
    VOID *mem;

    fread(&w, 2, 1, F);
    fread(&h, 2, 1, F);

    if ((mem = malloc(3 * w * h)) != NULL)
    {
      fread(mem, 3, w * h, F);

      glBindTexture(GL_TEXTURE_2D, Uni->TexId[1]);
      glTexImage2D(GL_TEXTURE_2D, 0, 3, w, h, 0, GL_BGR_EXT, GL_UNSIGNED_BYTE, mem);

      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
      glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);


      free(mem);
    }

    fclose(F);
  }  */
} /* End of 'PG3_UnitInit' function */

/* Unit deinitialization function.
 * ARGUMENTS:
 *   - self-pointer to unit object:
 *       pg3UNIT_BALL *Uni;
 *   - animation context:
 *       pg3ANIM *Ani;
 * RETURNS: None.
 */
static VOID PG3_UnitClose( pg3UNIT_TEXTURE *Uni, pg3ANIM *Ani )
{
  glDeleteTextures(1, &Uni->TexId); /* 2 */
  PG3_RndPrimFree(&Uni->Pr);
} /* End of 'PG3_UnitClose' function */

/* Unit inter frame events handle function.
 * ARGUMENTS:
 *   - self-pointer to unit object:
 *       pg3UNIT_BALL *Uni;
 *   - animation context:
 *       pg3ANIM *Ani;
 * RETURNS: None.
 */
static VOID PG3_UnitResponse( pg3UNIT_TEXTURE *Uni, pg3ANIM *Ani )
{

} /* End of 'PG3_UnitResponse' function */

/* Unit render function.
 * ARGUMENTS:
 *   - self-pointer to unit object:
 *       pg3UNIT_BALL *Uni;
 *   - animation context:
 *       pg3ANIM *Ani;
 * RETURNS: None.
 */
static VOID PG3_UnitRender( pg3UNIT_TEXTURE *Uni, pg3ANIM *Ani )
{
  glActiveTexture(GL_TEXTURE0 + 5);
  glBindTexture(GL_TEXTURE_2D, Uni->TexId);

 /* glActiveTexture(GL_TEXTURE0 + 1);
  glBindTexture(GL_TEXTURE_2D, Uni->TexId[1]); */

  PG3_RndPrimDraw(&Uni->Pr, MatrIdentity());   /* PG3_RndPrimDraw(&Uni->Texture, MatrTranslate(Uni->Pos)); */
} /* End of 'PG3_UnitRender' function */


pg3UNIT * PG3_UnitCreateTexture( VOID )
{
  pg3UNIT_TEXTURE *Uni;

  if ((Uni = (pg3UNIT_TEXTURE *)PG3_AnimUnitCreate(sizeof(pg3UNIT_TEXTURE))) == NULL)
    return NULL;
  Uni->Init = (VOID *)PG3_UnitInit;
  Uni->Close = (VOID *)PG3_UnitClose;
  Uni->Response = (VOID *)PG3_UnitResponse;
  Uni->Render = (VOID *)PG3_UnitRender;
  return (pg3UNIT *)Uni;
}

/* END of 'u_tex.c' FILE */

  