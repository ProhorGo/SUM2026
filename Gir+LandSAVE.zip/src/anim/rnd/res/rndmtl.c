/* FILE NAME: rndshd.c
* PROGRAMMER: PG3
*/

#include "anim/rnd/rnd.h"
#include "../../anim.h"
#include <stdio.h>

INT PG3_RndMaterialsSize;

static struct
{
  char *Name;
  VEC amb, dif, spec;
  FLT shin;
} MtlLib[] =
{
  {"Black Plastic", {0.0, 0.0, 0.0},             {0.01, 0.01, 0.01},           {0.5, 0.5, 0.5},               32},
  {"Brass",         {0.329412,0.223529,0.027451}, {0.780392,0.568627,0.113725}, {0.992157,0.941176,0.807843}, 27.8974},
  {"Bronze",        {0.2125,0.1275,0.054},       {0.714,0.4284,0.18144},       {0.393548,0.271906,0.166721},  25.6},
  {"Chrome",        {0.25, 0.25, 0.25},          {0.4, 0.4, 0.4},              {0.774597, 0.774597, 0.774597}, 76.8},
  {"Copper",        {0.19125,0.0735,0.0225},     {0.7038,0.27048,0.0828},      {0.256777,0.137622,0.086014},  12.8},
  {"Gold",          {0.24725,0.1995,0.0745},     {0.75164,0.60648,0.22648},    {0.628281,0.555802,0.366065},  51.2},
  {"Peweter",       {0.10588,0.058824,0.113725}, {0.427451,0.470588,0.541176}, {0.3333,0.3333,0.521569},      9.84615},
  {"Silver",        {0.19225,0.19225,0.19225},   {0.50754,0.50754,0.50754},    {0.508273,0.508273,0.508273},  51.2},
  {"Polished Silver", {0.23125,0.23125,0.23125}, {0.2775,0.2775,0.2775},       {0.773911,0.773911,0.773911},  89.6},
  {"Turquoise",     {0.1, 0.18725, 0.1745},      {0.396, 0.74151, 0.69102},    {0.297254, 0.30829, 0.306678}, 12.8},
  {"Ruby",          {0.1745, 0.01175, 0.01175},  {0.61424, 0.04136, 0.04136},  {0.727811, 0.626959, 0.626959}, 76.8},
  {"Polished Gold", {0.24725, 0.2245, 0.0645},   {0.34615, 0.3143, 0.0903},    {0.797357, 0.723991, 0.208006}, 83.2},
  {"Polished Bronze", {0.25, 0.148, 0.06475},    {0.4, 0.2368, 0.1036},        {0.774597, 0.458561, 0.200621}, 76.8},
  {"Polished Copper", {0.2295, 0.08825, 0.0275}, {0.5508, 0.2118, 0.066},      {0.580594, 0.223257, 0.0695701}, 51.2},
  {"Jade",          {0.135, 0.2225, 0.1575},     {0.135, 0.2225, 0.1575},      {0.316228, 0.316228, 0.316228}, 12.8},
  {"Obsidian",      {0.05375, 0.05, 0.06625},    {0.18275, 0.17, 0.22525},     {0.332741, 0.328634, 0.346435}, 38.4},
  {"Pearl",         {0.25, 0.20725, 0.20725},    {1.0, 0.829, 0.829},          {0.296648, 0.296648, 0.296648}, 11.264},
  {"Emerald",       {0.0215, 0.1745, 0.0215},    {0.07568, 0.61424, 0.07568},  {0.633, 0.727811, 0.633},       76.8},
  {"Black Plastic", {0.0, 0.0, 0.0},             {0.01, 0.01, 0.01},           {0.5, 0.5, 0.5},                32.0},
  {"Black Rubber",  {0.02, 0.02, 0.02},          {0.01, 0.01, 0.01},           {0.4, 0.4, 0.4},                10.0},
};
#define MAT_N (sizeof(MtlLib) / sizeof(MtlLib[0]))
    /*
pg3MATERIAL PG3_RndMtlGetDef( VOID )
{
  pg3MATERIAL def_mtl =
  {
    "Default",
    {0.1, 0.1, 0.1},
    {0.90, 0.90, 0.90},
    {0.30, 0.30, 0.30},
    30, 1,
    {-1, -1, -1, -1, -1, -1, -1, -1},
    0
  };
 
  return def_mtl;
} */
 
pg3MATERIAL PG3_RndMtlGetDef( VOID )
{
  INT i;
  pg3MATERIAL mtl;

  memset(&mtl, 0, sizeof(mtl));
  strncpy(mtl.Name, "Default", PG3_STR_MAX - 1);
  mtl.Ka = VecSet1(0.1);
  mtl.Kd = VecSet1(0.9);
  mtl.Ks = VecSet1(0.2);
  mtl.Ph = 30;
  mtl.Trans = 1;
  for (i = 0; i < 8; i++)
    mtl.Tex[i] = -1;
  return mtl;
}  

pg3MATERIAL * PG3_RndMtlGet( INT MtlNo )
{
  if (MtlNo < 0 || MtlNo >= PG3_RndMaterialsSize)
    MtlNo = 0;
  return &PG3_RndMaterials[MtlNo];
} 
 
VOID PG3_RndMtlInit( VOID )
{
  pg3MATERIAL mtl = PG3_RndMtlGetDef();
  INT i;
 
  PG3_RndMaterialsSize = 0;
  PG3_RndMtlAdd(&mtl);
  for (i = 0; i < MAT_N; i++)
  {
    strcpy(mtl.Name, "std::");
    strcat(mtl.Name, MtlLib[i].Name);
    mtl.Ka = MtlLib[i].amb; 
    mtl.Kd = MtlLib[i].dif;
    mtl.Ks = MtlLib[i].spec;
    mtl.Ph = MtlLib[i].shin;
    PG3_RndMtlAdd(&mtl);
  }
}

VOID PG3_RndMtlClose( VOID ) // � �������� ������ �������
{
  PG3_RndMaterialsSize = 0;
}
 
INT PG3_RndMtlAdd( pg3MATERIAL *Mtl )
{
 // -- ���������� ����� ������������ ��������� � ������� (RndMaterials)
 
  if (PG3_RndMaterialsSize >= PG3_MAX_MATERIALS)
    return 0;
  PG3_RndMaterials[PG3_RndMaterialsSize] = *Mtl;
  return PG3_RndMaterialsSize++;
}                         
 
INT PG3_RndMtlApply( INT MtlNo )
{                   
  INT prg;
  pg3MATERIAL *mtl;
  INT loc, i;
 
  mtl = PG3_RndMtlGet(MtlNo);
 
  /* Set shader program Id */
  prg = mtl->ShdNo;
  if (prg < 0 || prg >= PG3_RndShadersSize)
    prg = 0;
  prg = PG3_RndShaders[prg].ProgId;
 
  if (prg == 0)
    return 0;
  glUseProgram(prg);
 
   /* Set shading parameters */
  if ((loc = glGetUniformLocation(prg, "Ka")) != -1)
    glUniform3fv(loc, 1, &mtl->Ka.X);
  if ((loc = glGetUniformLocation(prg, "Kd")) != -1)
    glUniform3fv(loc, 1, &mtl->Kd.X);
  if ((loc = glGetUniformLocation(prg, "Ks")) != -1)
    glUniform3fv(loc, 1, &mtl->Ks.X);
  if ((loc = glGetUniformLocation(prg, "Ph")) != -1)
    glUniform1f(loc, mtl->Ph);
  if ((loc = glGetUniformLocation(prg, "Trans")) != -1)
    glUniform1f(loc, mtl->Trans);

  /* Set textures */
  for (i = 0; i < 8; i++)
  {
    CHAR tname[] = "IsTexture0";
    CHAR tnamew[] = "Texture0W";
    CHAR tnameh[] = "Texture0H";
    BOOL IsTex = FALSE;
 
    tname[9] = '0' + i;
    tnamew[7] = '0' + i;
    tnameh[7] = '0' + i;
    if (mtl->Tex[i] != -1 && mtl->Tex[i] >= 0 && mtl->Tex[i] < PG3_RndTexturesSize)
    {
      glActiveTexture(GL_TEXTURE0 + i);
      glBindTexture(GL_TEXTURE_2D, PG3_RndTextures[mtl->Tex[i]].TexId);
    }
    if ((loc = glGetUniformLocation(prg, tname)) != -1)
      glUniform1i(loc, mtl->Tex[i] != -1);
    if ((loc = glGetUniformLocation(prg, tnamew)) != -1)
      glUniform1f(loc, PG3_RndTextures[mtl->Tex[i]].W);
    if ((loc = glGetUniformLocation(prg, tnameh)) != -1)
      glUniform1f(loc, PG3_RndTextures[mtl->Tex[i]].H); 
  }
  return prg;
}