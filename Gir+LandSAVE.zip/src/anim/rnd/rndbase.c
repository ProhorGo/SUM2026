/* FILE NAME: rndbase.c
 * PROGRAMMER: PG3
 */
#include "rnd.h"
#include <wglew.h>
#include <gl/wglext.h>

#pragma comment(lib, "opengl32")


VOID PG3_RndInit( HWND hWnd )
{
  INT i;
  PIXELFORMATDESCRIPTOR pfd = {0};
  HGLRC hRC;
  INT PixelAttribs[] =
  {
    WGL_DRAW_TO_WINDOW_ARB, TRUE,
    WGL_SUPPORT_OPENGL_ARB, TRUE,
    WGL_DOUBLE_BUFFER_ARB, TRUE,
    WGL_PIXEL_TYPE_ARB, WGL_TYPE_RGBA_ARB,
    WGL_ACCELERATION_ARB, WGL_FULL_ACCELERATION_ARB,
    WGL_COLOR_BITS_ARB, 32,
    WGL_DEPTH_BITS_ARB, 32,
    0
  };
  INT ContextAttribs[] =
  {
    WGL_CONTEXT_MAJOR_VERSION_ARB, 4,
    WGL_CONTEXT_MINOR_VERSION_ARB, 6,
    WGL_CONTEXT_PROFILE_MASK_ARB, WGL_CONTEXT_COMPATIBILITY_PROFILE_BIT_ARB,
                                  /* WGL_CONTEXT_CORE_PROFILE_BIT_ARB, */
    0
  };

  PG3_hRndWnd = hWnd;
 
  /* Prepare frame compatible device contesxt */
  PG3_hRndDC = GetDC(hWnd);
 
  /* OpenGL init: pixel format setup */
  pfd.nSize = sizeof(PIXELFORMATDESCRIPTOR);
  pfd.nVersion = 1;
  pfd.dwFlags = PFD_DOUBLEBUFFER | PFD_SUPPORT_OPENGL;
  pfd.cColorBits = 32;
  pfd.cDepthBits = 32;
  i = ChoosePixelFormat(PG3_hRndDC, &pfd);
 
  DescribePixelFormat(PG3_hRndDC, i, sizeof(pfd), &pfd);
  SetPixelFormat(PG3_hRndDC, i, &pfd);
 
  /* OpenGL init: rendering context setup */
  PG3_hRndGLRC = wglCreateContext(PG3_hRndDC);
  wglMakeCurrent(PG3_hRndDC, PG3_hRndGLRC);

   if (glewInit() != GLEW_OK)
    exit(0);
 
  /* Render parameters setup */
  glEnable(GL_DEPTH_TEST);

  glEnable(GL_PRIMITIVE_RESTART);
  glPrimitiveRestartIndex(-1);

  wglSwapIntervalEXT(0);
 
  PG3_RndResize(47, 47);
 /* PG3_RndProjSize = 0.1;
  PG3_RndProjDist = PG3_RndProjSize;
  PG3_RndProjFarClip = 300;
  PG3_RndFrameW = 47;
  PG3_RndFrameH = 47;         */
  PG3_RndCamSet(VecSet(5, 5, 5), VecSet(0, 0, 0), VecSet(0, 1, 0));

  PG3_RndResInit();
}

VOID PG3_RndClose( VOID )
{
  PG3_RndResClose();

  wglMakeCurrent(NULL, NULL);
  wglDeleteContext(PG3_hRndGLRC);
  ReleaseDC(PG3_hRndWnd, PG3_hRndDC);
}

VOID PG3_RndResize( INT W, INT H )
{
  glViewport(0, 0, W, H);
 
  /* Setup projection */
  PG3_RndFrameW = W;
  PG3_RndFrameH = H;
  PG3_RndProjSet();
}
 
VOID PG3_RndCopyFrame( VOID )
{
  SwapBuffers(PG3_hRndDC);
}
 
/* - ��������� */
VOID PG3_RndStart( VOID )
{
  VEC4 ClearColor = {0.30, 0.47, 0.8, 1};
  FLT DepthClearValue = 1;
 
  /* Clear frame */
  glClearBufferfv(GL_COLOR, 0, &ClearColor.X);
  glClearBufferfv(GL_DEPTH, 0, &DepthClearValue);
 
}
 
VOID PG3_RndEnd( VOID )
{
  glFinish();
}
 
VOID PG3_RndProjSet( VOID )
{
  DBL rx, ry;
 
  rx = ry = PG3_RndProjSize;
  /* Correct aspect ratio */
  if (PG3_RndFrameW > PG3_RndFrameH)
    rx *= (DBL)PG3_RndFrameW / PG3_RndFrameH;
  else
    ry *= (DBL)PG3_RndFrameH / PG3_RndFrameW;
  PG3_RndMatrProj =
    MatrFrustum(-rx / 2, rx / 2, -ry / 2, ry / 2,
      PG3_RndProjDist, PG3_RndProjFarClip);
  PG3_RndMatrVP = MatrMulMatr(PG3_RndMatrView, PG3_RndMatrProj);
}

VOID PG3_RndCamSet( VEC Loc, VEC At, VEC Up )
{
  PG3_RndMatrView = MatrView(Loc, At, Up);
  PG3_RndMatrVP = MatrMulMatr(PG3_RndMatrView, PG3_RndMatrProj);
 
  PG3_RndCamRight = VecSet(PG3_RndMatrView.A[0][0],
                           PG3_RndMatrView.A[1][0],
                           PG3_RndMatrView.A[2][0]);
  PG3_RndCamUp = VecSet(PG3_RndMatrView.A[0][1],
                        PG3_RndMatrView.A[1][1],
                        PG3_RndMatrView.A[2][1]);
  PG3_RndCamDir = VecSet(-PG3_RndMatrView.A[0][2],
                         -PG3_RndMatrView.A[1][2],
                         -PG3_RndMatrView.A[2][2]);
  PG3_RndCamLoc = Loc;
  PG3_RndCamAt = At;
}

/* END of 'rndbase.c' FILE */
  