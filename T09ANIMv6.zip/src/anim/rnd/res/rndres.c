/* FILE NAME: rndres.c
 * PROGRAMMER: PG3
 */

#include "rndres.h"

VOID PG3_RndResInit( VOID )
{
}

VOID PG3_RndResClose( VOID )
{
}

/* END of 'rndres.c' FILE */