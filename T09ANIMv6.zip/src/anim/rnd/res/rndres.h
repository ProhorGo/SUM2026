/* FILE NAME: rndres.h
 * PROGRAMMER: PG3
 */

#include "def.h"

VOID PG3_RndResInit( VOID );
VOID PG3_RndResClose( VOID );

INT VG4_RndShdAdd( CHAR *ShaderFileNamePrefix );
VOID VG4_RndShdUpdate( VOID );
VOID VG4_RndShdInit( VOID );
VOID VG4_RndShdClose( VOID );

/* END of 'rndres.h' FILE */