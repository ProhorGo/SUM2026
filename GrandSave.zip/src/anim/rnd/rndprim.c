/* FILE NAME: rndprim.c
 * PROGRAMMER: PG3
 */

#include "rnd.h"
#include "anim/anim.h"
#include <string.h>   
#include <stdio.h>
 
VOID PG3_RndPrimCreate( pg3PRIM *Pr, pg3PRIM_TYPE Type,
                        pg3VERTEX *V, INT NoofV, INT *Ind, INT NoofI )
{
  INT i;

  memset(Pr, 0, sizeof(pg3PRIM));
  Pr->Trans = MatrIdentity();
  Pr->Type = Type;

  glGenVertexArrays(1, &Pr->VA);
  glBindVertexArray(Pr->VA);  

  /* Vertex data */
  if (V != NULL && NoofV != 0)
  {
    glGenBuffers(1, &Pr->VBuf);
    /* ������ �������� ����� */
    glBindBuffer(GL_ARRAY_BUFFER, Pr->VBuf);
    /* ������� ������ (NumOfV - ���������� ������, V - ������ ������) */
    glBufferData(GL_ARRAY_BUFFER, sizeof(pg3VERTEX) * NoofV, V, GL_STATIC_DRAW);
    /* ������������ � ������� ������ ����� � ������� (���� ��� �� ������) */
    glVertexAttribPointer(0, 3, GL_FLOAT, FALSE, sizeof(pg3VERTEX),
                          (VOID *)0); /* ������� */
    glVertexAttribPointer(1, 2, GL_FLOAT, FALSE, sizeof(pg3VERTEX),
                          (VOID *)sizeof(VEC)); /* ���������� ���������� */
    glVertexAttribPointer(2, 3, GL_FLOAT, FALSE, sizeof(pg3VERTEX),
                          (VOID *)(sizeof(VEC) + sizeof(VEC2))); /* ������� */
    glVertexAttribPointer(3, 4, GL_FLOAT, FALSE, sizeof(pg3VERTEX),
                          (VOID *)(sizeof(VEC) * 2 + sizeof(VEC2))); /* ���� */
    /* �������� ������ ��������� (layout) */
    glEnableVertexAttribArray(0);
    glEnableVertexAttribArray(1);
    glEnableVertexAttribArray(2);
    glEnableVertexAttribArray(3);
    /* ��������� ������ ������ */
   // glBindVertexArray(0);

    if (NoofV > 0)
    {
      Pr->MinBB = Pr->MaxBB = V[0].P;
      for (i = 1; i < NoofV; i++)
      {
        Pr->MinBB = VecMinVec(Pr->MinBB, V[i].P);
        Pr->MaxBB = VecMaxVec(Pr->MaxBB, V[i].P);
      }
    }
  }
 
  /* Index data */
  if (Ind != NULL && NoofI != 0)
  {
    glGenBuffers(1, &Pr->IBuf);
    /* ������ �������� ����� */
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, Pr->IBuf);
    /* ������� ������ (NumOfI - ���������� ��������, I - ������ ��������) */ 
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(INT) * NoofI, Ind, GL_STATIC_DRAW);
    //glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
    Pr->NumOfElements = NoofI;
  }
  else
    Pr->NumOfElements = NoofV;
  glBindVertexArray(0);
}   
  
VOID PG3_RndPrimFree( pg3PRIM *Pr )
{
  if (Pr == NULL)
	  return;
  glDeleteVertexArrays(1, &Pr->VA);
  glDeleteBuffers(1, &Pr->VBuf);
  glDeleteBuffers(1, &Pr->IBuf);
  glBindVertexArray(0);
  memset(Pr, 0, sizeof(pg3PRIM));   
}

VOID PG3_RndPrimDraw( pg3PRIM *Pr, MATR World )
{
  MATR w, wInv, wvp;
	 // wvp = MatrMulMatr3(Pr->Trans, World, PG3_RndMatrVP);
  UINT ProgId; //= PG3_RndShaders[0].ProgId;
  INT 
    loc,
    prim_type;

   if (Pr == NULL)
     return;
  
   w = MatrMulMatr(Pr->Trans, World);
   wInv = MatrTranspose(MatrInverse(w));
   wvp = MatrMulMatr(w, PG3_RndMatrVP);

   prim_type =
     Pr->Type == PG3_RND_PRIM_LINES ? GL_LINES :
     Pr->Type == PG3_RND_PRIM_TRIMESH ? GL_TRIANGLES :
     Pr->Type == PG3_RND_PRIM_TRISTRIP ? GL_TRIANGLE_STRIP :
     GL_POINTS;
  
  //glUseProgram(ProgId);
  //glUseProgram(0);
  /**/ Pr->MtlNo = 5;
  ProgId = PG3_RndMtlApply(Pr->MtlNo);
  if (ProgId == 0)
    return;
  if ((loc = glGetUniformLocation(ProgId, "MatrWVP")) != -1)
    glUniformMatrix4fv(loc, 1, FALSE, wvp.A[0]);
  if ((loc = glGetUniformLocation(ProgId, "MatrW")) != -1)
    glUniformMatrix4fv(loc, 1, FALSE, w.A[0]);
  if ((loc = glGetUniformLocation(ProgId, "MatrWInv")) != -1)
    glUniformMatrix4fv(loc, 1, FALSE, wInv.A[0]);
  if ((loc = glGetUniformLocation(ProgId, "Time")) != -1)
    glUniform1f(loc, PG3_Anim.Time);
  if ((loc = glGetUniformLocation(ProgId, "GlobalTime")) != -1)
    glUniform1f(loc, PG3_Anim.GlobalTime);
  if ((loc = glGetUniformLocation(ProgId, "CamLoc")) != -1)
    glUniform3fv(loc, 1, &PG3_RndCamLoc.X);

  glLoadMatrixf(wvp.A[0]);
 
  glBindVertexArray(Pr->VA);
  if (Pr->IBuf == 0)
    glDrawArrays(prim_type, 0, Pr->NumOfElements);
  else
  {
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, Pr->IBuf);
    glDrawElements(prim_type, Pr->NumOfElements, GL_UNSIGNED_INT, NULL);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);
  }
  glBindVertexArray(0);
  glUseProgram(0);
}
  
BOOL PG3_RndPrimLoad( pg3PRIM *Pr, CHAR *FileName )
{
  FILE *F;
  INT nv = 0, nf = 0, size;
  static CHAR Buf[3000];
  INT *Ind;
  pg3VERTEX *V;
 
  memset(Pr, 0, sizeof(pg3PRIM));
  
  if ((F = fopen(FileName, "r")) == NULL)
    return FALSE;
 
  /* Count vertices and indices */    
  while (fgets(Buf, sizeof(Buf) - 1, F) != NULL)
  {
    if (Buf[0] == 'v' && Buf[1] == ' ')
      nv++;
    else if (Buf[0] == 'f' && Buf[1] == ' ')
    {
      INT n = 0;
      CHAR *ptr = Buf + 2, oldc = ' ';
 
      while (*ptr != 0)
      {
        if (*ptr != ' ' && oldc == ' ')
          n++;
        oldc = *ptr++;
      }
 
      nf += n - 2;
    }
  }

  size = sizeof(pg3VERTEX) * nv + sizeof(INT) * nf * 3;
  if ((V = malloc(size)) == NULL)
    return FALSE;
  Ind = (INT *)(V + nv);
        
  /* Load model */                      
  rewind(F);
  nv = 0;
  nf = 0;
  while (fgets(Buf, sizeof(Buf) - 1, F) != NULL)
  {
    if (Buf[0] == 'v' && Buf[1] == ' ')
    {
      DBL x, y, z;
 
      sscanf(Buf + 2, "%lf%lf%lf", &x, &y, &z);
      V[nv++].P = VecSet(x, y, z);
    }
    else if (Buf[0] == 'f' && Buf[1] == ' ')
    {
      INT n, n1, n2, n3;
      INT fvn = 0;
      CHAR *ptr = Buf + 2, oldc = ' ';
 
      while (*ptr != 0)
      {
        if (*ptr != ' ' && oldc == ' ')
        {
          sscanf(ptr, "%d", &n);
          if (n > 0)
            n--;
          else
            if (n < 0)
              n = nv + n;
 
          if (fvn == 0)
            n1 = n;
          else if (fvn == 1)
            n2 = n;
          else
          {
            n3 = n;
 
            Ind[nf++] = n1;
            Ind[nf++] = n2;
            Ind[nf++] = n3;
 
            n2 = n3;
          }
          fvn++;
        }
        oldc = *ptr++;
      }
    }
  }
  fclose(F);
  PG3_RndPrimTriMeshAutoNormals(V, nv, Ind, nf);
  PG3_RndPrimCreate(Pr, PG3_RND_PRIM_TRIMESH, V,  nv, Ind, nf); 
  free(V);
  return TRUE;
}                                       
    
BOOL PG3_RndPrimCreateSphere( pg3PRIM *Pr, DBL R, INT W, INT H )
{
  INT *Ind;
  pg3VERTEX *V;
  INT size;
  INT i, j, k;
  DBL theta, phi, nl;
  VEC L = VecNormalize(VecSet(1, 1, 1));
  VEC C = VecSet(Rnd0(), Rnd0(), Rnd0());

  memset(Pr, 0, sizeof(pg3PRIM));
  size = sizeof(pg3VERTEX) * W * H + sizeof(INT) * (H - 1) * (W - 1) * 6;
  if ((V = malloc(size)) == NULL)
    return FALSE;
  Ind = (INT *)(V + W * H);  
 
  /* Fill vertex array */    
  for (k = 0, i = 0, theta = 0; i < H; i++, theta += PI / (H - 1))
    for (j = 0, phi = 0; j < W; j++, phi += 2 * PI / (W - 1))
    {
      V[k].N = VecSet(sin(theta) * sin(phi),
                      cos(theta),
                      sin(theta) * cos(phi));
      nl = VecDotVec(L, V[k].N);
      if (nl < 0.1)
        nl = 0.1;
      V[k].C = Vec4SetVec3(VecMulNum(C, nl));
      V[k++].P = VecSet(R * sin(theta) * sin(phi),
                        R * cos(theta),
                        R * sin(theta) * cos(phi));
    }
                                            
  /* Fill vertex array */           
  for (k = 0, i = 0; i < H - 1; i++)
    for (j = 0; j < W - 1; j++)
    {
      /* bottom-left */   
      Ind[k++] = i * W + j;
      Ind[k++] = i * W + j + 1;
      Ind[k++] = (i + 1) * W + j;
      /* top-right */       
      Ind[k++] = (i + 1) * W + j;
      Ind[k++] = i * W + j + 1;
      Ind[k++] = (i + 1) * W + j + 1;
    }
  PG3_RndPrimCreate(Pr, PG3_RND_PRIM_TRIMESH, V, W * H, Ind, (H - 1) * (W - 1) * 2 * 3);
  free(V);
  return TRUE;
}               

VOID PG3_RndPrimTriMeshAutoNormals( pg3VERTEX *V, INT NumOfV, INT *Ind, INT NumOfI )
{
  INT i;

  for (i = 0; i < NumOfV; i++)
    V[i].N = VecSet(0, 0, 0);
 

  for (i = 0; i < NumOfI; i += 3)
  {
    VEC
      p0 = V[Ind[i]].P,
      p1 = V[Ind[i + 1]].P,
      p2 = V[Ind[i + 2]].P,
      N = VecNormalize(VecCrossVec(VecSubVec(p1, p0), VecSubVec(p2, p0)));

    V[Ind[i]].N = VecAddVec(V[Ind[i]].N, N);
    V[Ind[i + 1]].N = VecAddVec(V[Ind[i + 1]].N, N);
    V[Ind[i + 2]].N = VecAddVec(V[Ind[i + 2]].N, N);
  }

  for (i = 0; i < NumOfV; i++)
    V[i].N = VecNormalize(V[i].N);
}
 

/* END of 'rndprim.c' FILE */