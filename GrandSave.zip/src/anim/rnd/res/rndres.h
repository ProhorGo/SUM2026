    /* FILE NAME: rndres.h
 * PROGRAMMER: PG3
 */

#include "def.h"

#define PG3_STR_MAX 100

VOID PG3_RndResInit( VOID );
VOID PG3_RndResClose( VOID );

extern UINT PG3_RndProgId;


/* shaders */
typedef struct tagpg3SHADER
{
  CHAR Name[PG3_STR_MAX]; /* Shader filename prefix */
  INT ProgId;             /* Shader program Id */
} pg3SHADER;

#define PG3_MAX_SHADERS 30
pg3SHADER PG3_RndShaders[PG3_MAX_SHADERS]; /* Array of shaders */
INT PG3_RndShadersSize;                    /* Shadres array store size */

VOID PG3_RndShdInit( VOID );
VOID PG3_RndShdClose( VOID ); 

INT PG3_RndShdAdd( CHAR *ShaderFileNamePrefix ); 
VOID PG3_RndShdUpdate( VOID );




/* textures */
typedef struct tagpg3TEXTURE
{
  CHAR Name[PG3_STR_MAX]; /* Texture name */
  INT W, H;               /* Texture size in pixels */
  UINT TexId;             /* OpenGL texture Id */ 
} pg3TEXTURE;
#define PG3_MAX_TEXTURES 3000
pg3TEXTURE PG3_RndTextures[PG3_MAX_TEXTURES]; /* Array of textures */
INT PG3_RndTexturesSize;    

VOID PG3_RndTexInit( VOID ); 
VOID PG3_RndTexClose( VOID ); 
 
INT PG3_RndTexAddImg( CHAR *Name, INT W, INT H, INT C, VOID *Bits );
INT PG3_RndTexAdd( CHAR *FileName ); 




/* materials */
typedef struct tagpg3MATERIAL
{
  CHAR Name[PG3_STR_MAX]; /* Material name */
 
  /* Illumination coefficients */    
  VEC Ka, Kd, Ks;           /* Ambient, diffuse, specular coefficients */
  FLT Ph;                   /* Phong power coefficient */
 
  FLT Trans;                /* Transparency factor */
 
  INT Tex[8];               /* Texture references from texture table (or -1) */
 
  INT ShdNo;                /* Shader number in shader table */
} pg3MATERIAL;

#define PG3_MAX_MATERIALS 300
pg3MATERIAL PG3_RndMaterials[PG3_MAX_MATERIALS]; /* Array of materials */
INT PG3_RndMaterialsSize; 

VOID PG3_RndMtlInit( VOID ); 
VOID PG3_RndMtlClose( VOID );

pg3MATERIAL PG3_RndMtlGetDef( VOID );
INT PG3_RndMtlAdd( pg3MATERIAL *Mtl );
INT PG3_RndMtlApply( INT MtlNo );
pg3MATERIAL * PG3_RndMtlGetByNo( INT MtlNo );

 
/* END of 'rndres.h' FILE */