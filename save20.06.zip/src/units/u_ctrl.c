/* FILE NAME: u_ctrl.c
 * PROGRAMMER: PG3
 */

#include "units.h"
#include <stdio.h>
#include <math.h>
#include <time.h>
 
typedef struct tagpg3UNIT_CONTROL
{
  PG3_UNIT_BASE_FIELDS;
  VEC CamLoc, CamAt;
  DBL Speed;
} pg3UNIT_CONTROL;

static pg3UNIT_CONTROL PG3_Move;  

static VOID PG3_UnitInit( pg3UNIT_CONTROL *Uni, pg3ANIM *Ani )
{
  Uni->CamLoc = VecSet(5, 5, 5);
  Uni->CamAt = VecSet(0, 0, 0);
  Uni->Speed = 5;
} 

static VOID PG3_UnitClose( pg3UNIT_CONTROL *Uni, pg3ANIM *Ani )
{
}

static VOID PG3_UnitRender( pg3UNIT_CONTROL *Uni, pg3ANIM *Ani )
{
  char head[102];

  if (Ani->IsPause)
    sprintf(head, "PAUSE");
  else          
    sprintf(head, "Pos: %.3f, %.3f, %.3f", Uni->CamLoc.X, Uni->CamLoc.Y, Uni->CamLoc.Z);
    //sprintf(head, "FPS: %.3f", Ani->FPS);
  SetWindowText(Ani->hWnd, head);
}

static VOID PG3_UnitResponse( pg3UNIT_CONTROL *Uni, pg3ANIM *Ani )
{
  VEC dv, NewLoc;
  DBL Dist, cosT, sinT, plen, cosP, sinP, Azimuth, Elevator, Wp, Hp, sx, sy;
  static VEC angle = {0, 0, 0};

  if (Ani->KeysClick['P'])
    Ani->IsPause = !Ani->IsPause;
  if (Ani->KeysClick[VK_ESCAPE])
    SendMessage(Ani->hWnd, WM_CLOSE, 0, 0);
  if (Ani->KeysClick[VK_F11])
    Uni->CamAt = VecSet(0, 0, 0);
  if (Ani->KeysClick[VK_F8])
  {
    HANDLE hCon = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_SCREEN_BUFFER_INFO info;
    DWORD NumCharsWritten;
    COORD Pos = {0};
 
    GetConsoleScreenBufferInfo(hCon, &info);
    FillConsoleOutputCharacter(hCon, ' ',
      (UINT)(info.dwSize.X * info.dwSize.Y), Pos, &NumCharsWritten);  
    FillConsoleOutputAttribute(hCon, 0x0F,
      (UINT)(info.dwSize.X * info.dwSize.Y), Pos, &NumCharsWritten);  
    SetConsoleCursorPosition(hCon, info.dwCursorPosition);
    SetConsoleCursorPosition(hCon, Pos);
  }

  if (!Ani->IsPause)
  {
    Dist = VecLen(VecSubVec(PG3_RndCamAt, PG3_RndCamLoc));
 
    cosT = (PG3_RndCamLoc.Y - PG3_RndCamAt.Y) / Dist;
    sinT = sqrt(1 - cosT * cosT);
     
    plen = Dist * sinT;
    cosP = (PG3_RndCamLoc.Z - PG3_RndCamAt.Z) / plen;
    sinP = (PG3_RndCamLoc.X - PG3_RndCamAt.X) / plen;
     
    Azimuth = R2D(atan2(sinP, cosP));
    Elevator = R2D(atan2(sinT, cosT));  


    Azimuth += Ani->GlobalDeltaTime * 
      47 * (Ani->Keys[VK_LEFT] - Ani->Keys[VK_RIGHT]) +  
     -30 * Ani->Keys[VK_LBUTTON] * Ani->Mdx;            
 
    Elevator += Ani->GlobalDeltaTime *
      47 * (Ani->Keys[VK_UP] - Ani->Keys[VK_DOWN]) + 
      -30 * Ani->Keys[VK_LBUTTON] * Ani->Mdy;        
     
    Dist += Ani->GlobalDeltaTime *
      (10 * Ani->Mdz + 8 * (1 + Ani->Keys[VK_SHIFT] * 30) *
          (Ani->Keys[VK_NEXT] - Ani->Keys[VK_PRIOR])); 

    if (Elevator > 178)
      Elevator > 178;
    if (Elevator < 0)
      Elevator = 0;
    if (Dist < 0.01)
      Dist = 0.01;

    NewLoc =
      PointTransform(VecSet(0, Dist, 0),
                     MatrMulMatr(MatrRotateX(Elevator),
                                 MatrRotateY(Azimuth)));

    Wp = PG3_RndProjSize;
    Hp = PG3_RndProjSize;
     
    if (Ani->W > Ani->H)
      Wp *= (FLT)Ani->W / Ani->H;
    else
      Hp *= (FLT)Ani->H / Ani->W;
     
    sx = Ani->Keys[VK_RBUTTON] * -Ani->Mdx * Wp / Ani->W * Dist / PG3_RndProjDist;
    sy = Ani->Keys[VK_RBUTTON] * Ani->Mdy * Hp / Ani->H * Dist / PG3_RndProjDist;
     

    dv = VecAddVec(VecMulNum(PG3_RndCamRight, sx),
                       VecMulNum(PG3_RndCamUp, sy));
    PG3_RndCamAt = VecAddVec(PG3_RndCamAt, dv);
    PG3_RndCamLoc = VecAddVec(PG3_RndCamLoc, dv);
     
    NewLoc = PointTransform(VecSet(0, Dist, 0),
                            MatrMulMatr(MatrRotateX(Elevator),
                                        MatrRotateY(Azimuth)));
     
    PG3_RndCamSet(PointTransform(VecSet(0, Dist, 0),
                                 MatrMulMatr3(MatrRotateX(Elevator),
                                              MatrRotateY(Azimuth),
                                              MatrTranslate(PG3_RndCamAt))),
                  PG3_RndCamAt,
                  VecSet(0, 1, 0));

  }
} 

pg3UNIT * PG3_UnitCreateControl( VOID )
{
  pg3UNIT *Uni;

  if ((Uni = PG3_AnimUnitCreate(sizeof(pg3UNIT_CONTROL))) == NULL)
    return NULL;
  Uni->Init = (VOID *)PG3_UnitInit;
  Uni->Close = (VOID *)PG3_UnitClose;
  Uni->Response = (VOID *)PG3_UnitResponse;
  Uni->Render = (VOID *)PG3_UnitRender;
  return Uni;
}       

/* 
static VOID PG3_UnitResponse( pg3UNIT_CONTROL *Uni, pg3ANIM *Ani )
{
  VEC d, e;
  DBL FullSpeed = Uni->Speed * Ani->DeltaTime * 3;
  RECT rc;
  POINT pt;
  static VEC angle = {0, 0, 0};

  if (Ani->KeysClick['P'])
    Ani->IsPause = !Ani->IsPause;
  if (Ani->KeysClick[VK_ESCAPE])
    SendMessage(Ani->hWnd, WM_CLOSE, 0, 0);
  if (Ani->KeysClick[VK_F11])
    Uni->CamAt = VecSet(0, 0, 0);
  if (Ani->KeysClick[VK_F8])
  {
    HANDLE hCon = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_SCREEN_BUFFER_INFO info;
    DWORD NumCharsWritten;
    COORD Pos = {0};
 
    GetConsoleScreenBufferInfo(hCon, &info);
    FillConsoleOutputCharacter(hCon, ' ',
      (UINT)(info.dwSize.X * info.dwSize.Y), Pos, &NumCharsWritten);  
    FillConsoleOutputAttribute(hCon, 0x0F,
      (UINT)(info.dwSize.X * info.dwSize.Y), Pos, &NumCharsWritten);  
    SetConsoleCursorPosition(hCon, info.dwCursorPosition);
    SetConsoleCursorPosition(hCon, Pos);
  }

  if (!Ani->IsPause)
  {
    angle.Y -= Ani->Mdx * 0.003;
    angle.X -= Ani->Mdy * 0.003;

    GetClientRect(Ani->hWnd, &rc);
    pt.x = rc.right / 2;
    pt.y = rc.bottom / 2;
    ClientToScreen(Ani->hWnd, &pt);
    // SetCursorPos(pt.x, pt.y);

    d = VecNormalize(VecSet(sin(angle.Y) * cos(angle.X), sin(angle.X), cos(angle.Y) * cos(angle.X)));
    e = VecNormalize(VecCrossVec(d, VecSet(0, 1, 0)));

    Uni->CamLoc =
	  PointTransform(Uni->CamLoc,
	    MatrRotateY(Ani->Keys[VK_LBUTTON] * -0.5 * Ani->Mdx));     

    if (Ani->Keys['W'])
	  Uni->CamLoc = VecAddVec(Uni->CamLoc, VecMulNum(d, FullSpeed));
    if (Ani->Keys['S'])
	  Uni->CamLoc = VecSubVec(Uni->CamLoc, VecMulNum(d, FullSpeed));
    if (Ani->Keys['D'])
	  Uni->CamLoc = VecAddVec(Uni->CamLoc, VecMulNum(e, FullSpeed));
    if (Ani->Keys['A'])
	  Uni->CamLoc = VecSubVec(Uni->CamLoc, VecMulNum(e, FullSpeed));
    if (Ani->Keys[VK_SPACE])
	  Uni->CamLoc = VecAddVec(Uni->CamLoc, VecSet(0, FullSpeed, 0));
    if (Ani->Keys[VK_LSHIFT])
	  Uni->CamLoc = VecSubVec(Uni->CamLoc, VecSet(0, FullSpeed, 0));

    Uni->CamAt = VecAddVec(Uni->CamLoc, d);
    PG3_RndCamSet(Uni->CamLoc, Uni->CamAt, VecSet(0, 1, 0));
  }
} 
*/