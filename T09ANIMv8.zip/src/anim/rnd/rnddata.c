/* FILE NAME: rnddata.c
 * PROGRAMMER: PG3
 */

#include "rnd.h"

HGLRC PG3_hRndGLRC;
HWND PG3_hRndWnd = NULL;
HDC PG3_hRndDC = NULL;
/*HBITMAP PG3_hRndBmFrame = NULL;   */
INT PG3_RndFrameH = 0;
INT PG3_RndFrameW = 0; 

HGLRC PG3_hRndGLRC;

DBL
  PG3_RndProjSize = 0.1,     /* Project plane fit square */
  PG3_RndProjDist = 0.1,     /* Distance to project plane from viewer (near) */
  PG3_RndProjFarClip = 300;  /* Distance to project far clip plane (far) */
 
MATR
  PG3_RndMatrView, /* View coordinate system matrix */
  PG3_RndMatrProj, /* Projection coordinate system matrix */
  PG3_RndMatrVP;   /* Stored (View * Proj) matrix */

VEC PG3_RndCamLoc, 
    PG3_RndCamAt, 
    PG3_RndCamDir,
    PG3_RndCamRight, 
    PG3_RndCamUp;

/* END of 'rnddata.c' FILE */
 