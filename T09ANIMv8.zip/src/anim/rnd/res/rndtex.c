/* FILE NAME: rndtex.c
 * PROGRAMMER: PG3
 */

#include "../rnd.h"

pg3TEXTURE PG3_RndTextures[PG3_MAX_TEXTURES]; /* Array of textures */
INT PG3_RndTexturesSize;                      /* Textures array store size */
 
VOID PG3_RndTexInit( VOID )
{
}

VOID PG3_RndTexClose( VOID )
{
}
 
INT PG3_RndTexAddImg( CHAR *Name, INT W, INT H, INT C, VOID *Bits )
{
  return -1;
}

INT PG3_RndTexAdd( CHAR *FileName )
{
  return -1;
}