/* FILE NAME: rndres.c
 * PROGRAMMER: PG3
 */

#include "rndres.h"

VOID PG3_RndResInit( VOID )
{
  PG3_RndShdInit();
  PG3_RndTexInit();
  PG3_RndMtlInit();
}

VOID PG3_RndResClose( VOID )
{
  PG3_RndMtlClose();
  PG3_RndTexClose();
  PG3_RndShdClose();
}

/* END of 'rndres.c' FILE */