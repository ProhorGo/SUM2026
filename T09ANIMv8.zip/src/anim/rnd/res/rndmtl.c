/* FILE NAME: rndmtl.h
 * PROGRAMMER: PG3
 */

//#include "../rnd.h"
#include "../../anim.h"

INT PG3_RndMaterialsSize = 300;                        /* Materials array    */
pg3MATERIAL PG3_RndMaterials[PG3_MAX_MATERIALS];       /* Array of materials */
 
pg3MATERIAL PG3_RndMtlGetDef( VOID )
{
  pg3MATERIAL def_mtl =
  {
    "Default",
    {0.1, 0.1, 0.1},
    {0.90, 0.90, 0.90},
    {0.30, 0.30, 0.30},
    30, 1,
    {-1, -1, -1, -1, -1, -1, -1, -1},
    0
  };
 
  return def_mtl;
}

VOID PG3_RndMtlClose( VOID )
{
  PG3_RndMaterialsSize = 0;
}
  
INT PG3_RndMtlAdd( pg3MATERIAL *Mtl )
{
  if (PG3_RndMaterialsSize >= PG3_MAX_MATERIALS)
    return 0;
  PG3_RndMaterials[PG3_RndMaterialsSize] = *Mtl;
  return PG3_RndMaterialsSize++;
}

VOID PG3_RndMtlInit( VOID )
{
  pg3MATERIAL def = PG3_RndMtlGetDef();
 
  PG3_RndMaterialsSize = 0;
  PG3_RndMtlAdd(&def);
}
  
UINT PG3_RndMtlApply( INT MtlNo )
{
  UINT prg;
  pg3MATERIAL *mtl;
  INT i, loc;
 
  /* Set material pointer */
  if (MtlNo < 0 || MtlNo >= PG3_RndMaterialsSize)
    MtlNo = 0;
  mtl = &PG3_RndMaterials[MtlNo];
 
  /* Set shader program Id */
  prg = mtl->ShdNo;
  if (prg < 0 || prg >= PG3_RndShadersSize)
    prg = 0;
  prg = PG3_RndShaders[prg].ProgId;
 
  if (prg == 0)
    return 0;
 
  glUseProgram(prg);
 
  if ((loc = glGetUniformLocation(prg, "Time")) != -1)
    glUniform1f(loc, PG3_Anim.Time);
  if ((loc = glGetUniformLocation(prg, "GlobalTime")) != -1)
    glUniform1f(loc, PG3_Anim.GlobalTime);
 
  /* Set shading parameters */
  if ((loc = glGetUniformLocation(prg, "Ka")) != -1)
    glUniform3fv(loc, 1, &mtl->Ka.X);
  if ((loc = glGetUniformLocation(prg, "Kd")) != -1)
    glUniform3fv(loc, 1, &mtl->Kd.X);
  if ((loc = glGetUniformLocation(prg, "Ks")) != -1)
    glUniform3fv(loc, 1, &mtl->Ks.X);
  if ((loc = glGetUniformLocation(prg, "Ph")) != -1)
    glUniform1f(loc, mtl->Ph);
  if ((loc = glGetUniformLocation(prg, "Trans")) != -1)
    glUniform1f(loc, mtl->Trans);
 
  /* Set textures */
  for (i = 0; i < 8; i++)
  {
  }
}
 