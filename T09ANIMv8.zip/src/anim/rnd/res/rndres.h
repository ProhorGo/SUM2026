/* FILE NAME: rndres.h
 * PROGRAMMER: PG3
 */

#ifndef __rndres_h_
#define __rndres_h_

#include "def.h"

#define PG3_STR_MAX 300

extern UINT PG3_RndProgId;

VOID PG3_RndResInit( VOID );
VOID PG3_RndResClose( VOID );


/* shaders */
typedef struct tagpg3SHADER
{
  CHAR Name[PG3_STR_MAX]; /* Shader filename prefix */
  INT ProgId;             /* Shader program Id */
} pg3SHADER;
#define PG3_MAX_SHADERS 30
extern pg3SHADER PG3_RndShaders[PG3_MAX_SHADERS];
extern INT PG3_RndShadersSize;

VOID PG3_RndShdInit( VOID );
VOID PG3_RndShdClose( VOID );

INT PG3_RndShdAdd( CHAR *ShaderFileNamePrefix );
VOID PG3_RndShdUpdate( VOID );




/* materials */
typedef struct tagpg3MATERIAL
{
  CHAR Name[PG3_STR_MAX]; /* Material name */
 
  /* Illumination coefficients */    
  VEC Ka, Kd, Ks;           /* Ambient, diffuse, specular coefficients */
  FLT Ph;                   /* Phong power coefficient */
 
  FLT Trans;                /* Transparency factor */
 
  INT Tex[8];               /* Texture references from texture table (or -1) */
 
  INT ShdNo;                /* Shader number in shader table */
} pg3MATERIAL;
 
#define PG3_MAX_MATERIALS 300
extern pg3MATERIAL PG3_RndMaterials[PG3_MAX_MATERIALS];
extern INT PG3_RndMaterialsSize;

VOID PG3_RndMtlInit( VOID );
VOID PG3_RndMtlClose( VOID );

pg3MATERIAL PG3_RndMtlGetDef( VOID );
INT PG3_RndMtlAdd( pg3MATERIAL *Mtl );
UINT PG3_RndMtlApply( INT MtlNo );
pg3MATERIAL * PG3_RndMtlGetByNo( INT MtlNo );




/* textures */
typedef struct tagpg3TEXTURE
{
  CHAR Name[PG3_STR_MAX]; /* Texture name */
  INT W, H;               /* Texture size in pixels */
  UINT TexId;             /* OpenGL texture Id */ 
} pg3TEXTURE;
#define PG3_MAX_TEXTURES 300
extern pg3TEXTURE PG3_RndTextures[PG3_MAX_TEXTURES];
extern INT PG3_RndTexturesSize;

VOID PG3_RndTexInit( VOID );
VOID PG3_RndTexClose( VOID );

INT PG3_RndTexAddImg( CHAR *Name, INT W, INT H, INT C, VOID *Bits );
INT PG3_RndTexAdd( CHAR *FileName );

#endif

/* END of 'rndres.h' FILE */