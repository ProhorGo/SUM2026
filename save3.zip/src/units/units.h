/* FILE NAME: units.h
 * PROGRAMMER: PG3
 */

#include "anim\anim.h"

pg3UNIT * PG3_UnitCreateBall( VEC Pos );

extern INT PG3_MouseWheel;

struct pg3UNIT_CONTROL;

pg3UNIT * PG3_UnitCreateTexture( VEC Pos );

//struct pg3UNIT_TEXTURE;

pg3UNIT * PG3_UnitCreateLandscape( VOID );


/* END of 'units.h' FILE */
