/* FILE NAME: u_ball.h
 * PROGRAMMER: PG3
 */

#include "units.h"

typedef struct tagpg3UNIT_TEXTURE
{
  PG3_UNIT_BASE_FIELDS;
  pg3PRIM Pr;
  INT MtlNo, TexId;
} pg3UNIT_TEXTURE;

/* Unit initialization function.
 * ARGUMENTS:
 *   - self-pointer to unit object:
 *       pg3UNIT_BALL *Uni;
 *   - animation context:
 *       pg3ANIM *Ani;
 * RETURNS: None.
 */
static VOID PG3_UnitInit( pg3UNIT_TEXTURE *Uni, pg3ANIM *Ani )
{
  pg3VERTEX V[] =
  {
    {{0, 0, 0}, {0, 0}, {0, 0, 1}, {1, 1, 1, 1}},
    {{1, 0, 0}, {1, 0}, {0, 0, 1}, {1, 1, 1, 1}},
    {{0, 1, 0}, {0, 1}, {0, 0, 1}, {1, 1, 1, 1}},
    {{1, 1, 0}, {1, 1}, {0, 0, 1}, {1, 1, 1, 1}},
  };
 
  FLT t[2][2] =
  {
    {0.8, 1},
    {1, 0.3}
  };
  pg3MATERIAL mtl = PG3_RndMtlGetDef();

  strncpy(mtl.Name, "Texture sample", PG3_STR_MAX - 1);
  mtl.ShdNo = PG3_RndShdAdd("tex");

  glGenTextures(1, &Uni->TexId);
  glBindTexture(GL_TEXTURE_2D, Uni->TexId);
  glTexImage2D(GL_TEXTURE_2D, 0, 1, 2, 2, 0, GL_LUMINANCE, GL_FLOAT, t);

  PG3_RndPrimCreate(&Uni-Pr, PG3_RND_PRIM_TRISTRIP, NULL, 4, NULL, 0);
} /* End of 'PG3_UnitInit' function */

/* Unit deinitialization function.
 * ARGUMENTS:
 *   - self-pointer to unit object:
 *       pg3UNIT_BALL *Uni;
 *   - animation context:
 *       pg3ANIM *Ani;
 * RETURNS: None.
 */
static VOID PG3_UnitClose( pg3UNIT_TEXTURE *Uni, pg3ANIM *Ani )
{
  glDeleteTexture(1, &Uni->TexId);
  PG3_RndPrimFree(&Uni->Texture);
} /* End of 'PG3_UnitClose' function */

/* Unit inter frame events handle function.
 * ARGUMENTS:
 *   - self-pointer to unit object:
 *       pg3UNIT_BALL *Uni;
 *   - animation context:
 *       pg3ANIM *Ani;
 * RETURNS: None.
 */
static VOID PG3_UnitResponse( pg3UNIT_TEXTURE *Uni, pg3ANIM *Ani )
{

} /* End of 'PG3_UnitResponse' function */

/* Unit render function.
 * ARGUMENTS:
 *   - self-pointer to unit object:
 *       pg3UNIT_BALL *Uni;
 *   - animation context:
 *       pg3ANIM *Ani;
 * RETURNS: None.
 */
static VOID PG3_UnitRender( pg3UNIT_TEXTURE *Uni, pg3ANIM *Ani )
{
  glActiveTexture(GL_TEXTURE0 + 1);
  glBindTexture(GL_TEXTURE_2D, Uni->TexId);

  PG3_RndPrimDraw(&Uni->Texture, MatrTranslate(Uni->Pos));
} /* End of 'PG3_UnitRender' function */

pg3UNIT * PG3_UnitCreateTexture( VEC Pos )
{
  pg3UNIT_TEXTURE *Uni;

  if ((Uni = (pg3UNIT_TEXTURE *)PG3_AnimUnitCreate(sizeof(pg3UNIT_TEXTURE))) == NULL)
    return NULL;
  Uni->Init = (VOID *)PG3_UnitInit;
  Uni->Close = (VOID *)PG3_UnitClose;
  Uni->Response = (VOID *)PG3_UnitResponse;
  Uni->Render = (VOID *)PG3_UnitRender;
  Uni->Pos = Pos;
  return (pg3UNIT *)Uni;
}

/* END of 'u_tex.c' FILE */

  