/* FILE NAME: rnd.h
 * PROGRAMMER: PG3
 */

#ifndef __rnd_h_
#define __rnd_h_

#define GLEW_STATIC
#include <glew.h>

#include "def.h"
#include "res/rndres.h"

/***
 * Base render support
 ***/

extern HGLRC PG3_hRndGLRC;

extern HWND PG3_hRndWnd;        /* Work window handle */
extern HDC PG3_hRndDC;     /* Work window memory device context  */
/* extern HBITMAP PG3_hRndBmFrame; */ /* Work window background bitmap handle */
extern INT PG3_RndFrameW, PG3_RndFrameH; /* Work window size */
extern DBL
  PG3_RndProjSize,     /* Project plane fit square */
  PG3_RndProjDist,     /* Distance to project plane from viewer (near) */
  PG3_RndProjFarClip;  /* Distance to project far clip plane (far) */
 
extern MATR
  PG3_RndMatrView, /* View coordinate system matrix */
  PG3_RndMatrProj, /* Projection coordinate system matrix */
  PG3_RndMatrVP;

VOID PG3_RndInit( HWND hWnd );
VOID PG3_RndClose( VOID );
VOID PG3_RndResize( INT W, INT H );
VOID PG3_RndCopyFrame( VOID );
VOID PG3_RndStart( VOID );
VOID PG3_RndProjSet( VOID );
VOID PG3_RndCamSet( VEC Loc, VEC At, VEC Up );
VOID PG3_RndEnd( VOID );

/***
 * Primitive handle
 ***/

/*typedef struct tagpg3VERTEX
{
  VEC P;  /* Vertex position */     /*     
} pg3VERTEX;                          */     

/* Vertex representation type */
typedef struct tagpg3VERTEX
{
  VEC P;   /* Vertex position */
  VEC2 T;  /* Vertex texture coordinate */
  VEC N;   /* Vertex normal */
  VEC4 C;  /* Vertex color */
} pg3VERTEX;
 
//typedef struct tagpg3PRIM
//{
//  pg3VERTEX *V; /* Vertex attributes array */
//  INT NumOfV;   /* Number of vertices */
// 
//  INT *I;       /* Index array (for trimesh � by 3 ones) */
//  INT NumOfI;   /* Number of indices */
// 
//  MATR Trans;   /* Additional transformation matrix */
//} pg3PRIM;


typedef enum tagpg3PRIM_TYPE
{
  PG3_RND_PRIM_POINTS,   /* Array of points  � GL_POINTS */
  PG3_RND_PRIM_LINES,    /* Line segments (by 2 points) � GL_LINES */
  PG3_RND_PRIM_TRIMESH,  /* Triangle mesh - array of triangles � GL_TRIANGLES */
  PG3_RND_PRIM_TRISTRIP,
} pg3PRIM_TYPE;

typedef struct tagpg3PRIM
{
  pg3PRIM_TYPE Type; /* Primitive type */

  INT
    VA,              /* Vertex array Id */
    VBuf,            /* Vertex buffer Id */
    IBuf;            /* Index buffer Id (if 0 - use only vertex buffer) */

  INT NumOfElements; /* Number of indices/vecrtices */

  VEC MinBB, MaxBB;  /* Bound box */

  MATR Trans;   /* Additional transformation matrix */
} pg3PRIM;
 

//BOOL PG3_RndPrimCreate( pg3PRIM *Pr, INT NoofV, INT NoofI );  
VOID PG3_RndPrimCreate( pg3PRIM *Pr, pg3PRIM_TYPE Type,
                        pg3VERTEX *V, INT NoofV, INT *Ind, INT NoofI );   
VOID PG3_RndPrimFree( pg3PRIM *Pr );
VOID PG3_RndPrimDraw( pg3PRIM *Pr, MATR World );
BOOL PG3_RndPrimLoad( pg3PRIM *Pr, CHAR *FileName );
BOOL PG3_RndPrimCreateSphere( pg3PRIM *Pr, DBL R, INT W, INT H );

VOID PG3_RndPrimTriMeshAutoNormals( pg3VERTEX *V, INT NumOfV, INT *Ind, INT NumOfI );

extern VEC PG3_RndCamLoc; 
extern VEC PG3_RndCamAt; 
extern VEC PG3_RndCamDir;
extern VEC PG3_RndCamRight;
extern VEC PG3_RndCamUp;

typedef struct tagpg3GRID
{
  INT W, H;
  pg3VERTEX *V;
} pg3GRID;

BOOL PG3_RndGridCreate( pg3GRID *G, INT W, INT H );

VOID PG3_RndGridFree( pg3GRID *G );

VOID PG3_RndPrimFromGrid( pg3PRIM *Pr, pg3GRID *G );

VOID PG3_RndGridAutoNormals( pg3GRID *G );

BOOL PG3_RndGridCreateSphere( pg3GRID *G, FLT R, INT W, INT H );

#endif 

/* END of 'rnd.h' FILE */