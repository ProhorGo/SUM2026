/* FILE NAME: rnd.h
 * PROGRAMMER: PG3
 */

#include "units.h"
#include <stdio.h>

typedef struct tagpg3UNIT_LAND
{
  PG3_UNIT_BASE_FIELDS;
  pg3PRIM Land;
} pg3UNIT_LAND;

static pg3UNIT_LAND PG3_Move;  

static VOID PG3_UnitInit( pg3UNIT_LAND *Uni, pg3ANIM *Ani )
{
  HBITMAP hBm;
  BITMAP bm;
  pg3GRID G;
 
  if ((hBm = LoadImage(NULL, "bin/heights/hfcolor.bmp", IMAGE_BITMAP, 0, 0,
                       LR_LOADFROMFILE | LR_CREATEDIBSECTION)) != NULL)
  {
    INT w, h;

    GetObject(hBm, sizeof(bm), &bm);
    w = bm.bmWidth;
    h = bm.bmHeight;

    if (bm.bmBitsPixel == 8 && PG3_RndGridCreate(&G, w, h))
    {
      BYTE *Bits = bm.bmBits;
      INT x, y;
 
      for (y = 0; y < h; y++)
        for (x = 0; x < w; x++)
        {
          INT hgt = Bits[(h - 1 - y) * bm.bmWidthBytes + x];
		  FLT hf = hgt / 255.0;
 
          G.V[y * G.W + x].P = VecSet(x / (w - 1.0) * 5000,
                                    hgt / 255.0 * 30,
                                    (1 - y / (h - 1.0)) * 5000);
		  G.V[y * G.W + x].T = Vec2Set(x / (w - 1.0),
                                       y / (h - 1.0));

		  if (hf < 0.3)
		    G.V[y * G.W + x].C = Vec4Set(0.1, 0.4, 0.1, 1);
		  else if (hf < 0.6)
		    G.V[y * G.W + x].C = Vec4Set(0.2, 0.7, 0.1, 1);
		  else /*if (hf < 0.8)*/
		    G.V[y * G.W + x].C = Vec4Set(0.4, 0.6, 0.1, 1);
		  //else 
		    //G.V[y * G.W + x].C = Vec4Set(0.8, 0.8, 0.8, 1);
        }
      PG3_RndGridAutoNormals(&G);
      PG3_RndPrimFromGrid(&Uni->Land, &G);
      PG3_RndGridFree(&G);
    }
  }
} 

static VOID PG3_UnitClose( pg3UNIT_LAND *Uni, pg3ANIM *Ani )
{
  PG3_RndPrimFree(&Uni->Land);
}

static VOID PG3_UnitRender( pg3UNIT_LAND *Uni, pg3ANIM *Ani )
{
  PG3_RndPrimDraw(&Uni->Land, MatrIdentity());
}

static VOID PG3_UnitResponse( pg3UNIT_LAND *Uni, pg3ANIM *Ani )
{
} 

pg3UNIT * PG3_UnitCreateLandscape( VOID )
{
  pg3UNIT *Uni;

  if ((Uni = PG3_AnimUnitCreate(sizeof(pg3UNIT_LAND))) == NULL)
    return NULL;
  Uni->Init = (VOID *)PG3_UnitInit;
  Uni->Close = (VOID *)PG3_UnitClose;
  Uni->Response = (VOID *)PG3_UnitResponse;
  Uni->Render = (VOID *)PG3_UnitRender;
  return Uni;
}       

/* END of 'u_land.c' FILE */