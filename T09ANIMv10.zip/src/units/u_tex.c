/* FILE NAME: u_ball.h
 * PROGRAMMER: PG3
 */

#include "units.h"

typedef struct tagpg3UNIT_TEXTURE
{
  PG3_UNIT_BASE_FIELDS;
  VEC Pos;
  pg3PRIM Texture;
} pg3UNIT_TEXTURE;

/* Unit initialization function.
 * ARGUMENTS:
 *   - self-pointer to unit object:
 *       pg3UNIT_BALL *Uni;
 *   - animation context:
 *       pg3ANIM *Ani;
 * RETURNS: None.
 */
static VOID PG3_UnitInit( pg3UNIT_TEXTURE *Uni, pg3ANIM *Ani )
{
  // //Uni->Pos = VecSet(0, 1, 0);
  //PG3_RndPrimCreateSphere(&Uni->Texture, 1, 47, 30);
} /* End of 'PG3_UnitInit' function */

/* Unit deinitialization function.
 * ARGUMENTS:
 *   - self-pointer to unit object:
 *       pg3UNIT_BALL *Uni;
 *   - animation context:
 *       pg3ANIM *Ani;
 * RETURNS: None.
 */
static VOID PG3_UnitClose( pg3UNIT_TEXTURE *Uni, pg3ANIM *Ani )
{
  PG3_RndPrimFree(&Uni->Texture);
} /* End of 'PG3_UnitClose' function */

/* Unit inter frame events handle function.
 * ARGUMENTS:
 *   - self-pointer to unit object:
 *       pg3UNIT_BALL *Uni;
 *   - animation context:
 *       pg3ANIM *Ani;
 * RETURNS: None.
 */
static VOID PG3_UnitResponse( pg3UNIT_TEXTURE *Uni, pg3ANIM *Ani )
{

} /* End of 'PG3_UnitResponse' function */

/* Unit render function.
 * ARGUMENTS:
 *   - self-pointer to unit object:
 *       pg3UNIT_BALL *Uni;
 *   - animation context:
 *       pg3ANIM *Ani;
 * RETURNS: None.
 */
static VOID PG3_UnitRender( pg3UNIT_TEXTURE *Uni, pg3ANIM *Ani )
{
  /* DrawSphere(Uni->Pos, 3); */
  PG3_RndPrimDraw(&Uni->Texture, MatrTranslate(Uni->Pos));
} /* End of 'PG3_UnitRender' function */

pg3UNIT * PG3_UnitCreateTexture( VEC Pos )
{
  pg3UNIT_TEXTURE *Uni;

  if ((Uni = (pg3UNIT_TEXTURE *)PG3_AnimUnitCreate(sizeof(pg3UNIT_TEXTURE))) == NULL)
    return NULL;
  Uni->Init = (VOID *)PG3_UnitInit;
  Uni->Close = (VOID *)PG3_UnitClose;
  Uni->Response = (VOID *)PG3_UnitResponse;
  Uni->Render = (VOID *)PG3_UnitRender;
  Uni->Pos = Pos;
  return (pg3UNIT *)Uni;
}

/* END of 'u_tex.c' FILE */

  